<footer class="hinl-footer" role="contentinfo">
  <div class="hinl-container">
    <div class="hinl-footer__grid">

      <!-- Brand -->
      <div>
        <img src="<?php echo esc_url(get_template_directory_uri() . '/images/logo.png'); ?>" alt="HINL" style="height:56px;width:auto;margin-bottom:1rem;">
        <p style="color:var(--hinl-outline);font-size:0.875rem;line-height:1.6;max-width:260px;">
          Nigeria&rsquo;s leading independent property inspection firm. Professional engineers protecting your real estate investment.
        </p>
        <div style="display:flex;gap:12px;margin-top:1.5rem;">
          <?php
          $socials = [
            ['href' => 'http://facebook.com/homeinspectorng',  'icon' => 'public'],
            ['href' => 'http://instagram.com/homeinspectorng', 'icon' => 'photo_camera'],
            ['href' => 'http://tiktok.com/homeinspectorng',    'icon' => 'play_circle'],
          ];
          foreach ($socials as $s): ?>
          <a href="<?php echo esc_url($s['href']); ?>" target="_blank" rel="noopener noreferrer"
             style="width:32px;height:32px;border-radius:50%;border:1px solid rgba(138,148,128,0.2);display:flex;align-items:center;justify-content:center;color:var(--hinl-outline);transition:color 0.2s,border-color 0.2s;"
             onmouseover="this.style.color='var(--hinl-primary)';this.style.borderColor='var(--hinl-primary)'"
             onmouseout="this.style.color='var(--hinl-outline)';this.style.borderColor='rgba(138,148,128,0.2)'">
            <span class="material-symbols-outlined" style="font-size:16px"><?php echo esc_html($s['icon']); ?></span>
          </a>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Services (hidden on mobile) -->
      <div class="hinl-footer__col--desktop-only">
        <div class="hinl-footer__col-title">Services</div>
        <ul class="hinl-footer__links">
          <?php
          $service_links = [
            ['label' => 'Standard Home Inspection',   'slug' => 'hinl-standard-home-inspection'],
            ['label' => 'Snag Inspection',             'slug' => 'hinl-snag-inspection'],
            ['label' => 'No Utility Inspection',       'slug' => 'hinl-no-utility-inspection'],
            ['label' => 'New Construction',            'slug' => 'hinl-new-construction-inspection'],
            ['label' => 'Commercial Inspection',       'slug' => 'hinl-commercial-building-inspection-consultancy'],
            ['label' => 'Construction Control',        'slug' => 'construction-control'],
            ['label' => 'Thermal Inspection',          'slug' => 'hinl-thermal-inspection'],
            ['label' => 'Virtual Reality',             'slug' => 'vr-home-inspection'],
          ];
          foreach ($service_links as $sl): ?>
          <li><a href="<?php echo esc_url(home_url('/' . $sl['slug'] . '/')); ?>"><?php echo esc_html($sl['label']); ?></a></li>
          <?php endforeach; ?>
        </ul>
      </div>

      <!-- Company -->
      <div>
        <div class="hinl-footer__col-title">Company</div>
        <ul class="hinl-footer__links">
          <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About Us</a></li>
          <li><a href="<?php echo esc_url(home_url('/diaspora-services/')); ?>">Diaspora Services</a></li>
          <li><a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a></li>
          <li><a href="<?php echo esc_url(home_url('/faqs/')); ?>">Useful Information</a></li>
          <li><a href="<?php echo esc_url(home_url('/careers/')); ?>">Careers</a></li>
          <li><a href="<?php echo esc_url(home_url('/services/')); ?>">View Pricing</a></li>
        </ul>
      </div>

      <!-- Legal (hidden on mobile) -->
      <div class="hinl-footer__col--desktop-only">
        <div class="hinl-footer__col-title">Legal</div>
        <ul class="hinl-footer__links">
          <li><a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a></li>
          <li><a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>">Terms of Service</a></li>
          <li><a href="https://www.homeinspectors.ng/wp-content/uploads/2025/04/NATIONAL-STANDARDS-OF-PRACTICE-1.pdf" target="_blank" rel="noopener noreferrer">Standards of Practice</a></li>
          <li><a href="https://www.homeinspectors.ng/wp-content/uploads/2025/04/NATIONAL-CODE-OF-CONDUCT-1.pdf" target="_blank" rel="noopener noreferrer">Code of Ethics</a></li>
        </ul>
      </div>

    </div>

    <div class="hinl-footer__bottom">
      <span>&copy; <?php echo date('Y'); ?> Home Inspection Nigeria Limited. All rights reserved.</span>
      <span style="color:rgba(138,148,128,0.4);">Independent &middot; Evidence-Based &middot; Trusted</span>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
